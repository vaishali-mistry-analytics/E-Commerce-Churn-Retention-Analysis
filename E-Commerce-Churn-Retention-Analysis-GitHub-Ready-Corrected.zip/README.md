# 🛒 E-Commerce Churn-Risk & Retention Analysis using MySQL

A portfolio data analytics project that uses SQL to analyze e-commerce customer behavior, purchasing patterns, revenue, customer segments, and **rule-based churn risk**.

> **Important:** This project uses synthetic data. The analysis identifies **churn-risk / at-risk customers using business rules**; it does not calculate a statistically validated historical churn rate or build a machine-learning churn model.

## 🎯 Business Objective

The goal is to convert customer, order, product, activity, and support data into actionable retention insights.

The project focuses on:

- Customer and order KPIs
- Revenue and Average Order Value
- Monthly revenue trends
- Product and category performance
- Repeat vs one-time customers
- Customer recency and purchase frequency
- RFM-style segmentation
- Rule-based at-risk customer identification
- Risk comparison across membership tiers, devices, and preferred categories
- Support interaction analysis
- Customer revenue contribution
- Return and cancellation rates

## ❓ Business Questions

1. How many customers and orders are in the dataset?
2. What is completed revenue and Average Order Value?
3. How does revenue change month by month?
4. Which product categories generate the most revenue and profit?
5. How many customers are repeat buyers?
6. Which customers have high purchase recency risk?
7. Which customer segments are high-value or at risk?
8. Which membership tiers and devices have higher risk rates?
9. Which products generate the most revenue?
10. What percentage of orders are cancelled or returned?
11. Which customers have high support interaction volume?
12. Which customers contribute the most revenue?

## 🗂️ Dataset

The project contains six synthetic CSV datasets:

| Table | Rows | Purpose |
|---|---:|---|
| customers | 1,500 | Customer profile and membership information |
| products | 100 | Product, category, price and cost |
| orders | 4,500 | Customer orders and order status |
| order_items | 11,218 | Products purchased in each order |
| customer_activity | 1,500 | Recency and recent activity |
| support_interactions | 2,200 | Customer support history |

## 🧩 Database Schema

```text
customers
   │
   ├── orders
   │      │
   │      └── order_items ─── products
   │
   ├── customer_activity
   │
   └── support_interactions
```

See `DATABASE_SCHEMA.txt` for the relationship summary.

## 🛠️ SQL Skills Demonstrated

- MySQL
- INNER JOIN / LEFT JOIN
- GROUP BY
- HAVING
- CASE statements
- Common Table Expressions (CTEs)
- Subqueries
- Conditional aggregation
- Window functions
- Date functions
- DENSE_RANK()
- LAG()
- Views
- KPI analysis
- Data validation
- Business-oriented SQL analysis

## 📊 Key Results from the Dataset

The source CSVs contain:

- **1,500 customers**
- **4,500 orders**
- **3,653 completed orders**
- **11,218 order items**
- **100 products**
- **2,200 support interactions**

Based on completed orders:

- Completed revenue: **₹305.57M**
- Average Order Value: **₹83,650.06**
- Repeat customers: **1,044**
- One-time customers: **324**
- Repeat-customer rate among customers with at least one completed order: **76.32%**
- Rule-based at-risk customers: **833 / 1,500 (55.53%)**
- Cancellation rate: **8.38%**
- Return rate: **10.44%**

### Revenue by Category

| Category | Completed Revenue |
|---|---:|
| Sports | ₹72.95M |
| Fashion | ₹69.62M |
| Electronics | ₹61.41M |
| Home & Kitchen | ₹60.00M |
| Beauty | ₹41.60M |

## ⚠️ Churn-Risk Definition

This project uses a simple business-rule proxy:

A customer is classified as **at risk** when:

```text
days_since_purchase > 180
OR
completed_orders <= 1
```

The RFM-style segmentation also considers:

- Recency
- Frequency
- Monetary value

These thresholds are portfolio/demo rules and should not be presented as a production churn model.

## 🚀 How to Run

### Step 1 — Create the database

Run:

```text
sql/01_database_setup.sql
```

### Step 2 — Load the CSV data

Run:

```text
sql/02_data_loading.sql
```

If `LOAD DATA LOCAL INFILE` is disabled in your MySQL environment, use **MySQL Workbench → Table Data Import Wizard** to import the six CSV files into the corresponding tables.

### Step 3 — Validate the data

Run:

```text
sql/00_data_validation.sql
```

The validation queries check:

- Row counts
- NULL primary keys
- Duplicate primary keys
- Foreign-key integrity
- Invalid prices/costs
- Invalid quantities
- Invalid discounts
- Invalid order statuses

### Step 4 — Run analysis

Run:

```text
sql/03_analysis_queries.sql
```

### Step 5 — Run business insights

Run:

```text
sql/04_business_insights.sql
```

## 📸 SQL Output Screenshots

Recommended portfolio screenshots are documented in:

```text
docs/SQL_SCREENSHOT_GUIDE.md
```

Capture result grids from MySQL Workbench rather than screenshots of long SQL code.

## 📁 Project Structure

```text
E-Commerce-Churn-Retention-Analysis/
│
├── README.md
├── DATABASE_SCHEMA.txt
├── .gitignore
│
├── data/
│   ├── customers.csv
│   ├── products.csv
│   ├── orders.csv
│   ├── order_items.csv
│   ├── customer_activity.csv
│   └── support_interactions.csv
│
├── sql/
│   ├── 00_data_validation.sql
│   ├── 01_database_setup.sql
│   ├── 02_data_loading.sql
│   ├── 03_analysis_queries.sql
│   └── 04_business_insights.sql
│
└── docs/
    ├── GITHUB_CHECKLIST.md
    ├── INTERVIEW_NOTES.md
    └── SQL_SCREENSHOT_GUIDE.md
```

## 💡 Business Recommendations

Based on the analysis, a business could:

- Target customers with long purchase gaps using personalized offers.
- Create retention campaigns for high-value at-risk customers.
- Compare customer experience and engagement across devices.
- Monitor product categories with strong revenue and profit contribution.
- Investigate returned and cancelled orders to identify operational issues.
- Use support-interaction patterns as an additional customer-risk signal.

## 🔮 Future Improvements

- Build a validated historical churn label
- Add customer lifetime value analysis
- Add cohort retention analysis
- Add tenure-band analysis
- Build an interactive Power BI dashboard
- Develop a machine-learning churn prediction model
- Automate monthly retention reporting

## 👩‍💻 Author

**Vaishali Mistry**

Aspiring Data Analyst | SQL | Excel | Power BI | Python

## ⚠️ Disclaimer

This project uses synthetic data and is created for educational and portfolio purposes. Business rules and thresholds are illustrative and should be validated before production use.
