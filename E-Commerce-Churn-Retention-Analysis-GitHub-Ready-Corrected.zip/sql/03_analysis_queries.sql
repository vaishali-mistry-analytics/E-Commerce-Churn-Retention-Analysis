USE ecommerce_churn_analysis;

-- 1. Total customers
SELECT COUNT(*) AS total_customers FROM customers;

-- 2. Total orders
SELECT COUNT(*) AS total_orders FROM orders;

-- 3. Completed revenue and Average Order Value
WITH completed_orders AS (
    SELECT o.order_id
    FROM orders o
    WHERE o.order_status = 'Completed'
),
order_revenue AS (
    SELECT
        oi.order_id,
        SUM(oi.quantity * p.price * (1 - oi.discount)) AS order_value
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    JOIN completed_orders co ON oi.order_id = co.order_id
    GROUP BY oi.order_id
)
SELECT
    ROUND(SUM(order_value), 2) AS completed_revenue,
    ROUND(AVG(order_value), 2) AS average_order_value
FROM order_revenue;

-- 4. Monthly revenue
SELECT
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    ROUND(SUM(oi.quantity * p.price * (1 - oi.discount)), 2) AS revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.order_status = 'Completed'
GROUP BY month
ORDER BY month;

-- 5. Revenue by category
SELECT
    p.category,
    ROUND(SUM(oi.quantity * p.price * (1 - oi.discount)), 2) AS revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.order_status = 'Completed'
GROUP BY p.category
ORDER BY revenue DESC;

-- 6. Top 10 products
SELECT
    p.product_name,
    p.category,
    ROUND(SUM(oi.quantity * p.price * (1 - oi.discount)), 2) AS revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.order_status = 'Completed'
GROUP BY p.product_id, p.product_name, p.category
ORDER BY revenue DESC
LIMIT 10;

-- 7. Repeat customers
SELECT COUNT(*) AS repeat_customers
FROM (
    SELECT customer_id
    FROM orders
    WHERE order_status = 'Completed'
    GROUP BY customer_id
    HAVING COUNT(DISTINCT order_id) > 1
) x;

-- 8. One-time customers
SELECT COUNT(*) AS one_time_customers
FROM (
    SELECT customer_id
    FROM orders
    WHERE order_status = 'Completed'
    GROUP BY customer_id
    HAVING COUNT(DISTINCT order_id) = 1
) x;

-- 9. Customer recency
SELECT
    c.customer_id,
    c.customer_name,
    a.last_purchase_date,
    DATEDIFF('2025-12-31', a.last_purchase_date) AS days_since_purchase
FROM customers c
JOIN customer_activity a ON c.customer_id = a.customer_id
ORDER BY days_since_purchase DESC;

-- 10. RFM-style segmentation
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.customer_name,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS frequency,
        COALESCE(SUM(
            CASE
                WHEN o.order_status = 'Completed'
                THEN oi.quantity * p.price * (1 - oi.discount)
                ELSE 0
            END
        ), 0) AS monetary_value
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    LEFT JOIN products p ON oi.product_id = p.product_id
    GROUP BY c.customer_id, c.customer_name, a.last_purchase_date
)
SELECT
    *,
    CASE
        WHEN recency_days <= 60 AND frequency >= 5 AND monetary_value >= 50000
            THEN 'Loyal / High Value'
        WHEN recency_days > 180 AND frequency <= 2
            THEN 'At Risk'
        WHEN recency_days > 300
            THEN 'Churn Risk'
        ELSE 'Regular'
    END AS customer_segment
FROM customer_metrics
ORDER BY monetary_value DESC;

-- 11. At-risk customers
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.customer_name,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, c.customer_name, a.last_purchase_date
)
SELECT *
FROM customer_metrics
WHERE recency_days > 180 OR completed_orders <= 1
ORDER BY recency_days DESC;

-- 12. Risk by membership tier
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.membership_tier,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, c.membership_tier, a.last_purchase_date
)
SELECT
    membership_tier,
    COUNT(*) AS customers,
    ROUND(100 * AVG(
        CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END
    ), 2) AS risk_rate_pct
FROM customer_metrics
GROUP BY membership_tier
ORDER BY risk_rate_pct DESC;

-- 13. Risk by preferred device
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.preferred_device,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, c.preferred_device, a.last_purchase_date
)
SELECT
    preferred_device,
    COUNT(*) AS customers,
    ROUND(100 * AVG(
        CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END
    ), 2) AS risk_rate_pct
FROM customer_metrics
GROUP BY preferred_device
ORDER BY risk_rate_pct DESC;

-- 14. Risk by preferred category
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.preferred_category,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, c.preferred_category, a.last_purchase_date
)
SELECT
    preferred_category,
    COUNT(*) AS customers,
    ROUND(100 * AVG(
        CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END
    ), 2) AS risk_rate_pct
FROM customer_metrics
GROUP BY preferred_category
ORDER BY risk_rate_pct DESC;

-- 15. Order status mix
SELECT
    order_status,
    COUNT(*) AS orders,
    ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_orders
FROM orders
GROUP BY order_status;

-- 16. Payment method
SELECT
    payment_method,
    COUNT(*) AS orders,
    ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS usage_pct
FROM orders
GROUP BY payment_method
ORDER BY orders DESC;

-- 17. Support issues
SELECT
    issue_type,
    COUNT(*) AS interactions,
    SUM(resolved = 'No') AS unresolved
FROM support_interactions
GROUP BY issue_type
ORDER BY interactions DESC;

-- 18. Support-heavy customers
SELECT
    c.customer_id,
    c.customer_name,
    COUNT(s.interaction_id) AS support_interactions,
    SUM(s.resolved = 'No') AS unresolved
FROM customers c
JOIN support_interactions s ON c.customer_id = s.customer_id
GROUP BY c.customer_id, c.customer_name
HAVING COUNT(s.interaction_id) >= 5
ORDER BY unresolved DESC, support_interactions DESC;

-- 19. Top 3 products per category
WITH product_sales AS (
    SELECT
        p.category,
        p.product_id,
        p.product_name,
        SUM(oi.quantity * p.price * (1 - oi.discount)) AS revenue
    FROM products p
    JOIN order_items oi ON p.product_id = oi.product_id
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.order_status = 'Completed'
    GROUP BY p.category, p.product_id, p.product_name
),
ranked_products AS (
    SELECT
        *,
        DENSE_RANK() OVER (PARTITION BY category ORDER BY revenue DESC) AS product_rank
    FROM product_sales
)
SELECT
    category,
    product_name,
    ROUND(revenue, 2) AS revenue,
    product_rank
FROM ranked_products
WHERE product_rank <= 3
ORDER BY category, product_rank;

-- 20. Monthly revenue growth
WITH monthly AS (
    SELECT
        DATE_FORMAT(o.order_date, '%Y-%m') AS month,
        SUM(oi.quantity * p.price * (1 - oi.discount)) AS revenue
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    WHERE o.order_status = 'Completed'
    GROUP BY month
)
SELECT
    month,
    ROUND(revenue, 2) AS revenue,
    ROUND(
        100 * (revenue - LAG(revenue) OVER (ORDER BY month))
        / NULLIF(LAG(revenue) OVER (ORDER BY month), 0),
        2
    ) AS mom_growth_pct
FROM monthly
ORDER BY month;

-- 21. Customer revenue contribution
WITH customer_sales AS (
    SELECT
        c.customer_id,
        c.customer_name,
        SUM(oi.quantity * p.price * (1 - oi.discount)) AS revenue
    FROM customers c
    JOIN orders o ON c.customer_id = o.customer_id
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN products p ON oi.product_id = p.product_id
    WHERE o.order_status = 'Completed'
    GROUP BY c.customer_id, c.customer_name
)
SELECT
    customer_id,
    customer_name,
    ROUND(revenue, 2) AS revenue,
    ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_contribution_pct
FROM customer_sales
ORDER BY revenue DESC;

-- 22. Top 20 customers by total spend
SELECT
    c.customer_id,
    c.customer_name,
    ROUND(SUM(oi.quantity * p.price * (1 - oi.discount)), 2) AS total_spend
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.order_status = 'Completed'
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spend DESC
LIMIT 20;

-- 23. Cancellation rate
SELECT
    ROUND(100 * SUM(order_status = 'Cancelled') / COUNT(*), 2) AS cancellation_rate_pct
FROM orders;

-- 24. Return rate
SELECT
    ROUND(100 * SUM(order_status = 'Returned') / COUNT(*), 2) AS return_rate_pct
FROM orders;

-- 25. Safe retention summary view
CREATE OR REPLACE VIEW customer_retention_summary AS
WITH customer_orders AS (
    SELECT
        o.customer_id,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders,
        ROUND(COALESCE(SUM(
            CASE
                WHEN o.order_status = 'Completed'
                THEN oi.quantity * p.price * (1 - oi.discount)
                ELSE 0
            END
        ), 0), 2) AS total_spend
    FROM orders o
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    LEFT JOIN products p ON oi.product_id = p.product_id
    GROUP BY o.customer_id
),
customer_support AS (
    SELECT
        customer_id,
        COUNT(*) AS support_interactions
    FROM support_interactions
    GROUP BY customer_id
)
SELECT
    c.customer_id,
    c.customer_name,
    c.membership_tier,
    c.preferred_device,
    a.last_purchase_date,
    DATEDIFF('2025-12-31', a.last_purchase_date) AS days_since_purchase,
    COALESCE(co.completed_orders, 0) AS completed_orders,
    COALESCE(co.total_spend, 0) AS total_spend,
    a.app_sessions_90d,
    a.wishlist_items,
    COALESCE(cs.support_interactions, 0) AS support_interactions
FROM customers c
JOIN customer_activity a ON c.customer_id = a.customer_id
LEFT JOIN customer_orders co ON c.customer_id = co.customer_id
LEFT JOIN customer_support cs ON c.customer_id = cs.customer_id;

-- View check
SELECT * FROM customer_retention_summary
LIMIT 25;
