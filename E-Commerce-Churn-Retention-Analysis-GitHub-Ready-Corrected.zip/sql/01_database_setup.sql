CREATE DATABASE IF NOT EXISTS ecommerce_churn_analysis;
USE ecommerce_churn_analysis;
DROP TABLE IF EXISTS support_interactions;
DROP TABLE IF EXISTS customer_activity;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
customer_id INT PRIMARY KEY, customer_name VARCHAR(100), gender VARCHAR(20), age INT,
city VARCHAR(100), state VARCHAR(100), join_date DATE, preferred_device VARCHAR(30),
membership_tier VARCHAR(30), preferred_category VARCHAR(100));

CREATE TABLE products (
product_id INT PRIMARY KEY, product_name VARCHAR(150), category VARCHAR(100),
sub_category VARCHAR(100), price DECIMAL(12,2), cost DECIMAL(12,2));

CREATE TABLE orders (
order_id INT PRIMARY KEY, customer_id INT, order_date DATE, payment_method VARCHAR(50),
order_status VARCHAR(30), shipping_city VARCHAR(100), shipping_state VARCHAR(100),
FOREIGN KEY(customer_id) REFERENCES customers(customer_id));

CREATE TABLE order_items (
order_item_id INT PRIMARY KEY, order_id INT, product_id INT, quantity INT, discount DECIMAL(5,2),
FOREIGN KEY(order_id) REFERENCES orders(order_id), FOREIGN KEY(product_id) REFERENCES products(product_id));

CREATE TABLE customer_activity (
customer_id INT PRIMARY KEY, last_purchase_date DATE, email_opt_in VARCHAR(10),
app_sessions_90d INT, wishlist_items INT, FOREIGN KEY(customer_id) REFERENCES customers(customer_id));

CREATE TABLE support_interactions (
interaction_id INT PRIMARY KEY, customer_id INT, interaction_date DATE, channel VARCHAR(30),
issue_type VARCHAR(50), resolved VARCHAR(10), FOREIGN KEY(customer_id) REFERENCES customers(customer_id));
