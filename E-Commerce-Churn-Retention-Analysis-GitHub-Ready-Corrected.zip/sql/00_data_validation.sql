USE ecommerce_churn_analysis;

-- 1. Row counts
SELECT 'customers' AS table_name, COUNT(*) AS row_count FROM customers
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL SELECT 'customer_activity', COUNT(*) FROM customer_activity
UNION ALL SELECT 'support_interactions', COUNT(*) FROM support_interactions;

-- 2. NULL primary-key checks
SELECT COUNT(*) AS null_customer_ids FROM customers WHERE customer_id IS NULL;
SELECT COUNT(*) AS null_product_ids FROM products WHERE product_id IS NULL;
SELECT COUNT(*) AS null_order_ids FROM orders WHERE order_id IS NULL;
SELECT COUNT(*) AS null_order_item_ids FROM order_items WHERE order_item_id IS NULL;
SELECT COUNT(*) AS null_activity_customer_ids FROM customer_activity WHERE customer_id IS NULL;
SELECT COUNT(*) AS null_interaction_ids FROM support_interactions WHERE interaction_id IS NULL;

-- 3. Duplicate primary-key checks (should return zero rows)
SELECT customer_id, COUNT(*) AS duplicate_count
FROM customers GROUP BY customer_id HAVING COUNT(*) > 1;

SELECT product_id, COUNT(*) AS duplicate_count
FROM products GROUP BY product_id HAVING COUNT(*) > 1;

SELECT order_id, COUNT(*) AS duplicate_count
FROM orders GROUP BY order_id HAVING COUNT(*) > 1;

SELECT order_item_id, COUNT(*) AS duplicate_count
FROM order_items GROUP BY order_item_id HAVING COUNT(*) > 1;

-- 4. Foreign-key integrity checks (should return zero rows)
SELECT o.order_id, o.customer_id
FROM orders o
LEFT JOIN customers c ON o.customer_id = c.customer_id
WHERE c.customer_id IS NULL;

SELECT oi.order_item_id, oi.order_id
FROM order_items oi
LEFT JOIN orders o ON oi.order_id = o.order_id
WHERE o.order_id IS NULL;

SELECT oi.order_item_id, oi.product_id
FROM order_items oi
LEFT JOIN products p ON oi.product_id = p.product_id
WHERE p.product_id IS NULL;

SELECT a.customer_id
FROM customer_activity a
LEFT JOIN customers c ON a.customer_id = c.customer_id
WHERE c.customer_id IS NULL;

SELECT s.interaction_id, s.customer_id
FROM support_interactions s
LEFT JOIN customers c ON s.customer_id = c.customer_id
WHERE c.customer_id IS NULL;

-- 5. Basic business-rule checks
SELECT COUNT(*) AS invalid_prices
FROM products WHERE price < 0 OR cost < 0;

SELECT COUNT(*) AS invalid_quantities
FROM order_items WHERE quantity <= 0;

SELECT COUNT(*) AS invalid_discounts
FROM order_items WHERE discount < 0 OR discount > 1;

SELECT COUNT(*) AS invalid_order_status
FROM orders
WHERE order_status NOT IN ('Completed','Returned','Cancelled');

-- Expected: all invalid_* checks should return 0.
