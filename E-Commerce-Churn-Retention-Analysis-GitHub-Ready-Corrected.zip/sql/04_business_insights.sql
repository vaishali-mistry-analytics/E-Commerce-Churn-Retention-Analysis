USE ecommerce_churn_analysis;

-- 1. Overall customer KPI
SELECT
    COUNT(*) AS total_customers,
    ROUND(AVG(DATEDIFF('2025-12-31', last_purchase_date)), 0) AS avg_days_since_purchase
FROM customer_activity;

-- 2. Repeat-customer rate among customers with at least one completed order
WITH customer_orders AS (
    SELECT customer_id, COUNT(DISTINCT order_id) AS completed_orders
    FROM orders
    WHERE order_status = 'Completed'
    GROUP BY customer_id
)
SELECT
    ROUND(
        100 * SUM(CASE WHEN completed_orders > 1 THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS repeat_customer_rate_pct
FROM customer_orders;

-- 3. At-risk rate
-- This is a portfolio rule-based risk proxy, NOT a true historical churn rate.
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, a.last_purchase_date
)
SELECT
    ROUND(
        100 * AVG(
            CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END
        ),
        2
    ) AS at_risk_rate_pct
FROM customer_metrics;

-- 4. High-value customers who are also at risk
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.customer_name,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COALESCE(SUM(
            CASE
                WHEN o.order_status = 'Completed'
                THEN oi.quantity * p.price * (1 - oi.discount)
                ELSE 0
            END
        ), 0) AS total_spend
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    LEFT JOIN products p ON oi.product_id = p.product_id
    GROUP BY c.customer_id, c.customer_name, a.last_purchase_date
)
SELECT
    customer_id,
    customer_name,
    recency_days,
    ROUND(total_spend, 2) AS total_spend
FROM customer_metrics
WHERE recency_days > 180
  AND total_spend >= 50000
ORDER BY total_spend DESC
LIMIT 20;

-- 5. Category revenue and profit
SELECT
    p.category,
    ROUND(SUM(oi.quantity * p.price * (1 - oi.discount)), 2) AS revenue,
    ROUND(SUM(
        oi.quantity * ((p.price * (1 - oi.discount)) - p.cost)
    ), 2) AS profit
FROM products p
JOIN order_items oi ON p.product_id = oi.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.order_status = 'Completed'
GROUP BY p.category
ORDER BY profit DESC;

-- 6. Business recommendation table: risk by membership
WITH customer_metrics AS (
    SELECT
        c.customer_id,
        c.membership_tier,
        DATEDIFF('2025-12-31', a.last_purchase_date) AS recency_days,
        COUNT(DISTINCT CASE WHEN o.order_status = 'Completed' THEN o.order_id END) AS completed_orders
    FROM customers c
    JOIN customer_activity a ON c.customer_id = a.customer_id
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id, c.membership_tier, a.last_purchase_date
)
SELECT
    membership_tier,
    COUNT(*) AS customers,
    SUM(CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END) AS at_risk_customers,
    ROUND(
        100 * AVG(CASE WHEN recency_days > 180 OR completed_orders <= 1 THEN 1 ELSE 0 END),
        2
    ) AS risk_rate_pct
FROM customer_metrics
GROUP BY membership_tier
ORDER BY risk_rate_pct DESC;
