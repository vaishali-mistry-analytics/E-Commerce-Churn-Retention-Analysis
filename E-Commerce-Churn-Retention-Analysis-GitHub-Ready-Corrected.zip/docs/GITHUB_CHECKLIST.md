# GitHub Upload Checklist

- [ ] README reviewed
- [ ] Synthetic-data disclaimer kept
- [ ] SQL scripts run successfully
- [ ] CSV row counts verified
- [ ] 5–8 useful screenshots added
- [ ] Screenshots show result sets, not personal information
- [ ] Repository name is professional
- [ ] No passwords, API keys or private files
- [ ] README has project objective, tools, questions, run steps and resume entry
