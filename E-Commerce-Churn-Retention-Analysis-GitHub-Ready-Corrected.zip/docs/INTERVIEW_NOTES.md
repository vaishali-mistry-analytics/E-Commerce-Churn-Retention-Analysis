# Interview Notes — E-Commerce Churn-Risk & Retention Analysis

## 30-second explanation

"I built an E-Commerce Churn-Risk and Retention Analysis project in MySQL to analyze customer purchasing behavior, revenue, recency, frequency and support interactions. I used JOINs, CTEs, conditional aggregation, window functions and views to identify at-risk and high-value customer groups and translate the results into retention-focused business recommendations."

## Important terminology

- Say **churn-risk / at-risk** rather than claiming a measured historical churn rate.
- The risk rule is: `days_since_purchase > 180 OR completed_orders <= 1`.
- The dataset is synthetic.
- The RFM-style thresholds are illustrative business rules.

## What not to claim

- Do not claim the dataset is from a real company.
- Do not claim causal relationships unless the analysis establishes them.
- Do not call the rule-based risk score a machine-learning model.
- Do not claim a true churn rate without a historical churn label.

## Recommended interview flow

Business problem → data model → data validation → SQL analysis → customer risk rule → insights → business recommendation.
