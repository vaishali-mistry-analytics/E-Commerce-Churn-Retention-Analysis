# SQL Screenshot Guide

Run the project in MySQL Workbench first. Capture the **result grid**, not a long block of SQL code.

Use these 8 screenshots for GitHub/LinkedIn:

## 01 — Data Validation
File: `sql/00_data_validation.sql`
Show:
- Row counts for all six tables
- Validation checks returning 0 invalid/orphan records

Suggested title: **Data Validation & Quality Checks**

## 02 — Customer & Order KPIs
File: `sql/03_analysis_queries.sql`
Run:
- Total customers
- Total orders
- Completed revenue / Average Order Value

Suggested title: **Customer & Order KPIs**

## 03 — Monthly Revenue
File: `sql/03_analysis_queries.sql`
Run query 4.

Suggested title: **Monthly Revenue Trend**

## 04 — Revenue by Category
File: `sql/03_analysis_queries.sql`
Run query 5.

Suggested title: **Revenue by Product Category**

## 05 — RFM-Style Segmentation
File: `sql/03_analysis_queries.sql`
Run query 10.

Suggested title: **RFM-Style Customer Segmentation**

## 06 — At-Risk Customer Analysis
File: `sql/03_analysis_queries.sql`
Run query 11.

Suggested title: **Rule-Based At-Risk Customers**

## 07 — Risk by Membership / Device
File: `sql/03_analysis_queries.sql`
Run queries 12 and 13.

Suggested title: **Customer Risk by Membership & Device**

## 08 — Business Insights
File: `sql/04_business_insights.sql`
Run:
- At-risk rate
- High-value at-risk customers
- Category revenue and profit

Suggested title: **Retention & Business Insights**

### Screenshot tips

- Keep the result grid large enough to read.
- Hide unnecessary desktop/background information.
- Do not show passwords, API keys or personal information.
- Use consistent screenshot naming:
  `01_data_validation.png`
  `02_customer_order_kpis.png`
  `03_monthly_revenue.png`
  `04_category_revenue.png`
  `05_rfm_segmentation.png`
  `06_at_risk_customers.png`
  `07_risk_segments.png`
  `08_business_insights.png`
